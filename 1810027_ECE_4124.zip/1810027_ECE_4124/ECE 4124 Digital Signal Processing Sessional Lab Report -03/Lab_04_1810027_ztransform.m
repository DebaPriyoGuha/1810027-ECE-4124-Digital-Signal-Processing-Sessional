clc;
clear all;

x=[1 2 3 4 5];


syms k z
f = sin(k);
ztrans(f, k, z)